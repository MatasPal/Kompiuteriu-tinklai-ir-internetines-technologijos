<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

// Create connection
$conn = new mysqli($server, $user, $password, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email)) {
        $email_error = 'Įveskite el. paštą.';
    }

    if (empty($password)) {
        $password_error = 'Įveskite slaptažodį.';
    }

    if (isset($email_error) || isset($password_error)) {
        $login_error = 'Neįvedėte visų prisijungimo duomenų.';
    } else {
        $sql = "SELECT * FROM ip_projektas WHERE el_pastas='$email' AND slaptazodis='$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $_SESSION['logged_in'] = true;

            // Retrieve the user's type from the database
            $row = $result->fetch_assoc();
            $vartotojo_tipas = $row['vartotojo_tipas'];
            $el_pastas = $row['el_pastas'];

            // Set the user's type in the session
            $_SESSION['user_type'] = $vartotojo_tipas;
            $_SESSION['user_email'] = $el_pastas;

			
			if ($vartotojo_tipas == "admin") {
                header('Location: admin.php');
			}
            if ($vartotojo_tipas == "standartinis" || $vartotojo_tipas == "pliusas") {
                header('Location: index.php');
			}

        } else {
            $login_error = 'Neteisingas el. paštas arba slaptažodis.';
        }
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Prisijungimas</title>
    <link rel="stylesheet" type="text/css" href="design.css">
</head>
<body>
    <div class="login-container">
        <h2>Prisijungimas</h2>
        <form action="login.php" method="POST">
            <div> 
                <input type="text" name="email" placeholder="El. paštas" class="login-input">
                
            </div><br>
            <div>
                <input type="password" name="password" placeholder="Slaptažodis" class="login-input">
				<?php if(isset($email_error)) { echo '<p style="color: red;">' . $email_error . '</p>'; } ?>
                <?php if(isset($password_error)) { echo '<p style="color: red;">' . $password_error . '</p>'; } ?>
				<?php if(isset($login_error)) { echo '<p style="color: red;">' . $login_error . '</p>'; } ?>
            </div><br>
            <button type="submit" name="submit" class="login-button">Prisijungti</button>
			<a href="register.php" type="submit" name="submit" >Registruotis</a>
            
        </form>
    </div>
</body>
</html>

