<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

// Create connection
$conn = new mysqli($server, $user, $password, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validation (you can customize this part)
    if (empty($name) || empty($surname) || empty($email) || empty($password)) {
        $error = 'Užpildykite visus laukus.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Neteisingas el. pašto formatas.';
    } else {
        // Check if the email already exists in the database
        $checkEmailQuery = "SELECT * FROM $lentele WHERE el_pastas='$email'";
        $result = $conn->query($checkEmailQuery);

        if ($result->num_rows > 0) {
            $error = 'Toks el. paštas jau užregistruotas.';
        } else {
            // Check if the password already exists in the database
            $checkPasswordQuery = "SELECT * FROM $lentele WHERE slaptazodis='$password'";
            $resultPassword = $conn->query($checkPasswordQuery);

            if ($resultPassword->num_rows > 0) {
                $error = 'Tokį slaptažodį jau naudoja kitas vartotojas.';
            } else {
                // Hash the password (you should use a more secure method)
                //$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Insert user data into the database
                $sql = "INSERT INTO $lentele (vardas, pavarde, el_pastas, vartotojo_tipas, slaptazodis)
                        VALUES ('$name', '$surname', '$email', 'standartinis', '$password')";

                if ($conn->query($sql) === TRUE) {
                    $_SESSION['success_message'] = "Sveikiname, sėkmingai prisiregistravus! Prašome prisijungti.";                  
					header("Location: register.php");
                    exit;
                } else {
                    $error = "DB registracijos klaida: " . $conn->error;
                }
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registracija</title>
    <link rel="stylesheet" type="text/css" href="design.css">
	<style>
.main {
            margin: 2em;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1em;
        }
        .th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .th {
            background-color: #0073e6;
            color: white;
        }

/*Admin page table*/
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1em;
}

/* Style for the registration input fields */
.register-input {
    width: 100%;
    padding: 10px;
    margin: 5px 0;
    border: 1px solid #ccc;
    border-radius: 3px;
    box-sizing: border-box;
    font-size: 16px;
}

.register-button, a.button {
            padding: 10px;
            background-color: #0073e6;
            color: white;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-right: 10px;
        }

        .register-button {
            float: left;
        }

        a.button {
            float: right;
        }

        .register-button:hover, a.button:hover {
            background-color: #00509e;
        }

        .a {
            color: #0073e6;
            text-decoration: none;
        }

/* Style for the registration container */
.register-container {
    width: 300px;
    margin: 0 auto;
    text-align: center;
}

/* Style for error messages */
.error-message {
    color: red;
}

/* Style for success messages */
.success-message {
    color: green;
}
	</style>
</head>
<body>
    <div class="register-container">
        <h2>Registracija</h2>
        <form action="register.php" method="POST">
            <div>
                <input type="text" name="name" placeholder="Vardas" class="register-input">
            </div><br>
            <div>
                <input type="text" name="surname" placeholder="Pavardė" class="register-input">
            </div><br>
            <div>
                <input type="text" name="email" placeholder="El. paštas" class="register-input">
            </div><br>
            <div>
                <input type="password" name="password" placeholder="Slaptažodis" class="register-input">
                <?php if (isset($error)) { echo '<p style="color: red;">' . $error . '</p>'; } ?>
            </div><br>
			<div>
                <p>Vartotojo tipas: Standartinis</p>
            </div><br>
            <button type="submit" name="submit" class="register-button">Registruotis</button>
            <a href="login.php" class="button">Prisijungti čia</a>
        </form>
		<?php
        if (isset($_SESSION['success_message'])) {
            echo '<script>alert("' . $_SESSION['success_message'] . '")</script>';
            unset($_SESSION['success_message']);
        }
        ?>
    </div>
</body>
</html>
