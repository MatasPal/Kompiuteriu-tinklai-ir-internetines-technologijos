<?php
session_start();
$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

$db = mysqli_connect($server, $user, $password, $db);
$sql = "SELECT vardas, vartotojo_tipas FROM " . $lentele . " ORDER BY vartotojo_tipas DESC, vardas";
$result = mysqli_query($db, $sql);

if (!$result || (mysqli_num_rows($result) < 1)) {
    echo "Klaida skaitant lentelę users";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administratoriaus sąsaja</title>
    <link rel="stylesheet" type="text/css" href="design.css">
  <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #0073e6;
            color: white;
            padding: 1em;
            text-align: center;
        }

        main {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1em;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #0073e6;
            color: white;
        }

        select {
            padding: 5px;
        }

        input[type="submit"], a.button {
            padding: 10px;
            background-color: #0073e6;
            color: white;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin-right: 10px;
        }

        input[type="submit"] {
            float: left;
        }

        a.button {
            float: right;
        }

        input[type="submit"]:hover, a.button:hover {
            background-color: #00509e;
        }

        a {
            color: #0073e6;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <table class="center">
            <tr>               
                 <center><font size="6">Nuotraukų konvertavimo puslapio naudotojų įgaliojimų pakeitimas</font></center>                
            </tr>
        </table>
    </header>
    <form name="vartotojai" action="procadmindb.php" method="post">
        <main>
            <table class="center table" border="1" cellspacing="0" cellpadding="3">
                <tr>
                    <th>Vartotojo vardas</th>
                    <th>Buvusi rolė</th>
                    <th>Nauja rolė</th>
                </tr>
                <?php
                $naikpoz = false;   // ar bus naikinamu vartotoju
                while ($row = mysqli_fetch_assoc($result)) {
                    $userRole = $row['vartotojo_tipas'];
                    $user = $row['vardas'];
					
                    $nlevel = $_POST['role_' . $user];
                    $naikinti = (isset($_POST['naikinti_' . $user]));

                    if ($naikinti || ($nlevel != $userRole)) {
                        $keisti[] = $user;  // cia isiminti kuriuos keiciam, ka keiciam bus irasyta i $pakeitimai
                        echo "<tr><td>" . $user . "</td><td>";    // rodyti sia eilute patvirtinimui

                        if ($userRole == 'uzblokuotas') {
                            echo "Užblokuotas";
                        } else {
                            echo $userRole;  // assuming user roles are stored as they are in the database
                        }

                        echo "</td><td>";

                        if ($naikinti) {
                            echo "<font color=red>PAŠALINTI</font>";
                            $pakeitimai[] = -1; // ir isiminti kad salinam
                            $naikpoz = true;
                        } else {
                            $pakeitimai[] = $nlevel;    // isiminti i kokia role
                            if ($nlevel == 'uzblokuotas') {
                                echo "UŽBLOKUOTAS";
                            } else {
                                echo $nlevel;  // assuming user roles are stored as they are in the database
                            }
                        }

                        echo "</td></tr>";
                    }
                }

                if ($naikpoz) {
                    echo "Ar tikrai norite pašalinti šį naudotoją/naudotojus?";
                }

                // pakeitimus irasysim i sesija 
                if (empty($keisti)) {
                    header("Location:index.php");
                    exit;  // nieko nekeicia
                }

                $_SESSION['ka_keisti'] = $keisti;
                $_SESSION['pakeitimai'] = $pakeitimai;
                ?>
            </table>
            <input type="submit" value="Atlikti">
            <a href="admin.php" class="button">Grįžti</a>
        </main>
    </form>
</body>
</html>
