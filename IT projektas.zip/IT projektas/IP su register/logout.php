<?php
// Start the session to access session data
session_start();

// Check if the user is logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    // If the user is logged in, unset and destroy the session
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session

    // Redirect the user to the login page or any other page you prefer after logging out
    header('Location: login.php');
    exit();
} else {
    // If the user is not logged in, you can redirect them to the login page
    header('Location: login.php');
    exit();
}
?>
