<?php
session_start();



date_default_timezone_set("Europe/Vilnius");

$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

$db = mysqli_connect($server, $user, $password, $db);
$sql = "SELECT vardas, pavarde, el_pastas, vartotojo_tipas, slaptazodis "
    . "FROM " . $lentele . " ORDER BY vartotojo_tipas DESC, vardas";
$result = mysqli_query($db, $sql);

if (!$result || (mysqli_num_rows($result) < 1)) {
    echo "Klaida skaitant lentelę users";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vartotojų Valdymas - Admin Puslapis</title>
	    <link rel="stylesheet" type="text/css" href="design.css">
    <style>
		
		#return-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px;
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }
       
        main {
            margin: 2em;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1em;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #0073e6;
            color: white;
        }
        select {
            padding: 5px;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #0073e6;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <h1>Nuotraukų konvertavimo sistema - Admin puslapis</h1>
		    <link rel="stylesheet" type="text/css" href="design.css">
		<a href="index.php" id="return-btn">Grįžti į index</a>
    </header>
    <main>
        <form name="vartotojai" href="design.css" action="procadmin.php" method="post">
            <table>
                <tr>
                    <th>Vardas</th>
					<th>Pavardė</th>                
                    <th>E-paštas</th>
					<th>Tipas</th>
					<th>Slaptažodis</th>
                    <th>Šalinti?</th>
                </tr>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    $user = $row['vardas'];
					$surname = $row['pavarde'];
                    $email = $row['el_pastas'];
					$userRole = $row['vartotojo_tipas'];
					$pass = $row['slaptazodis'];
                    ?>
                    <tr>
                        <td><?php echo $user; ?></td>
						<td><?php echo $surname; ?></td>
						<td><?php echo $email; ?></td>
                        <td>
                            <select name="role_<?php echo $user; ?>">
                                <?php
                                $userRoles = array(
                                    'standartinis' => 'Standartinis',
                                    'pliusas' => 'Pliusas',
                                    'admin' => 'Administratorius'
                                );
                                foreach ($userRoles as $role => $roleLabel) {
                                    echo "<option value=\"$role\"";
                                    if ($role == $userRole) {
                                        echo " selected";
                                    }
                                    echo ">$roleLabel</option>";
                                }
                                ?>
                            </select>
                        </td>
                        <td><?php echo $pass; ?></td>
                        <td><input type="checkbox" name="naikinti_<?php echo $user; ?>"></td>
                    </tr>
                <?php } ?>
            </table>
            <input type="submit" value="Vykdyti">
        </form>
    </main>
</body>
</html>

