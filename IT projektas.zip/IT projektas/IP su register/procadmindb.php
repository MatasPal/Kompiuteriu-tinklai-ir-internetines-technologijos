<?php
session_start();

$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

$db = mysqli_connect($server, $user, $password, $db);

$i = 0;
$levels = $_SESSION['pakeitimai'];

foreach ($_SESSION['ka_keisti'] as $user) {
    $level = $levels[$i++];
    if ($level == -1) {
        // Delete user
        $sql = "DELETE FROM " . $lentele . " WHERE vardas='$user'";
        if (!mysqli_query($db, $sql)) {
            echo "DB klaida šalinant vartotoją: " . $sql . "<br>" . mysqli_error($db);
            exit;
        }
    } else {
        // Update user level
        $sql = "UPDATE " . $lentele . " SET vartotojo_tipas='$level' WHERE vardas='$user'";
        if (!mysqli_query($db, $sql)) {
            echo "DB klaida keičiant vartotojo įgaliojimus: " . $sql . "<br>" . mysqli_error($db);
            exit;
        }
    }
}

$_SESSION['message'] = "Pakeitimai atlikti sėkmingai";
header("Location: admin.php");
exit;
?>
