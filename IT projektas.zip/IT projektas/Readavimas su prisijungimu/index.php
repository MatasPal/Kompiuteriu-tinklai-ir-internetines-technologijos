<?php
session_start();

// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>IP Projektas</title>
</head>
<body>
    <h1>Nuotraukų konvertavimo sistema</h1>
    <?php
    $fileNameNew = ''; // Inicializuojame kintamąjį, kad vėliau galėtume jį naudoti

    if(isset($_POST['submit'])){
        $file = $_FILES['file'];

        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileError = $_FILES['file']['error'];
        $fileType = $_FILES['file']['type'];

        $fileExt = explode('.', $fileName);
        $fileActualExt = strtolower(end($fileExt));

        $allowed = array('jpg', 'jpeg', 'png', 'pdf');

        if(in_array($fileActualExt, $allowed)){
            if($fileError === 0){
                if($fileSize < 1000000){
                    $fileNameNew = $fileName; // Nenaudojame unikalaus pavadinimo
                    $fileDestination = '/var/www/html/' . $fileNameNew;
                    if (file_exists($fileDestination)) {
                        echo "File with this name already exists. You can edit it.";
                    } else {
                        move_uploaded_file($fileTmpName, $fileDestination);
                    }
                } else {
                    echo "Your file is too big!";
                }
            } else {
                echo "There was an error uploading your file!";
            }
        } else {
            echo "You cannot upload files of this type!";
        }
    }
	
	

    
    ?>

    <form action="index.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <button type="submit" name="submit">UPLOAD</button>
    </form>

    <script>
        function resizeImage() {
            var uploadedImage = document.querySelector('img');
            var widthInput = document.getElementById('widthInput').value;
            var heightInput = document.getElementById('heightInput').value;

            if (widthInput > 0 && heightInput > 0 && widthInput <= uploadedImage.width && heightInput <= uploadedImage.height) {
                uploadedImage.style.width = widthInput + 'px';
                uploadedImage.style.height = heightInput + 'px';
            } else {
                alert('Neteisingai nurodyti matmenys arba bando didinti nuotrauka.');
            }
        }
    </script>
	<?php
	if (!empty($fileNameNew)) {
        echo '<h2>Jusu ikelta nuotrauka:</h2>';
        echo '<img src="' . $fileNameNew . '" style="max-width: 100%">';
		 // Gauti originalius matmenis
        $originalDimensions = getimagesize($fileNameNew);
        echo '<p>Originalūs matmenys: ' . $originalDimensions[0] . 'x' . $originalDimensions[1] . ' (plotis ir aukštis)</p>';
        echo '<h2>Redaguoti dydį:</h2>';
        echo '<div>';
        echo '    Plotis: <input type="number" id="widthInput" value=""> px';
        echo '    Aukštis: <input type="number" id="heightInput" value=""> px';
        echo '    <button onclick="resizeImage()">Redaguoti dydį</button>';
        echo '</div>';
    }
	?>
	
	<h2>Konvertuoti į kitą formatą:</h2>
<form action="index.php" method="POST">
    <select name="targetFormat">
        <option value="jpg">JPEG</option>
        <option value="png">PNG</option>
        <!-- Pridėkite kitus palaikomus formatus čia -->
    </select>
    <button type="submit" name="convert">Konvertuoti</button>
</form>

	<?php
	$fileNameNew = '';
$fileDestination = ''; // Pridėkite šią eilutę viršuje

if(isset($_POST['submit'])){
    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png', 'pdf');

    if(in_array($fileActualExt, $allowed)){
        if($fileError === 0){
            if($fileSize < 1000000){
                $fileNameNew = $fileName; // Nenaudojame unikalaus pavadinimo
                $fileDestination = '/var/www/html/' . $fileNameNew; // Priskiriame reikšmę čia
                if (file_exists($fileDestination)) {
                    echo "File with this name already exists. You can edit it.";
                } else {
                    move_uploaded_file($fileTmpName, $fileDestination);
                }
            } else {
                echo "Your file is too big!";
            }
        } else {
            echo "There was an error uploading your file!";
        }
    } else {
        echo "You cannot upload files of this type!";
    }
}



	?>
</body>
</html>


