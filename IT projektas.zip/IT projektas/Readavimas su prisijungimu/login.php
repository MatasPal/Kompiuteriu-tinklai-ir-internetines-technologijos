<?php
#session_start();

$server = "localhost";
$db = "stud";
$user = "stud";
$password = "stud";
$lentele = "ip_projektas";

// Create connection
$conn = new mysqli($server,$user,$password, $db);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM ip_projektas WHERE el_pastas='$email' AND slaptazodis='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['logged_in'] = true;
        header('Location: index.php');
    } else {
        echo "Invalid email or password. Please try again.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Prisijungimas</h2>
    <form action="login.php" method="POST">
        <input type="text" name="email" placeholder="El. paštas"><br><br>
        <input type="password" name="password" placeholder="Slaptažodis"><br><br>
        <button type="submit" name="submit">Prisijungti</button>
    </form>
</body>
</html>

